import { useEffect, useRef, useState } from 'react'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import {
  MapPin,
  Phone,
  Mail,
  Menu,
  X,
  GraduationCap,
  Heart,
  ArrowDown,
  Youtube,
  Linkedin,
  Facebook,
  Instagram,
  Twitter,
} from 'lucide-react'

gsap.registerPlugin(ScrollTrigger)

/* ─────────────── data ─────────────── */

const portfolioItems = [
  {
    img: '/images/portfolio-1.jpg',
    title: 'English Learning Hub',
    category: 'Educational Content',
  },
  {
    img: '/images/portfolio-2.jpg',
    title: 'Professional Placement Test',
    category: 'Web Development',
  },
  {
    img: '/images/portfolio-3.jpg',
    title: 'Personal Brand Identity',
    category: 'Graphic Design',
  },
  {
    img: '/images/portfolio-4.jpg',
    title: 'Social Media Content',
    category: 'Content Creation',
  },
]

const testimonials = [
  {
    avatar: '/images/avatar-1.jpg',
    quote:
      "Tamer's teaching method made English feel natural. His placement test helped me understand exactly where to start my learning journey.",
    name: 'Ahmed K.',
  },
  {
    avatar: '/images/avatar-2.jpg',
    quote:
      "The English Learning Hub content is incredibly well-structured. Tamer has a gift for explaining complex grammar in simple terms.",
    name: 'Nour S.',
  },
  {
    avatar: '/images/avatar-3.jpg',
    quote:
      "I worked with Tamer for years in dental technology. His attention to detail and dedication are unmatched. He brings that same precision to education.",
    name: 'Dr. Hassan M.',
  },
  {
    avatar: '/images/avatar-4.jpg',
    quote:
      "His TikTok videos are both fun and educational. I've learned more English vocabulary in a month than I did in a year of traditional classes.",
    name: 'Yasmin R.',
  },
  {
    avatar: '/images/avatar-5.jpg',
    quote:
      "Tamer designed our clinic's educational materials. The visual clarity and organization significantly improved patient understanding.",
    name: 'Omar F.',
  },
  {
    avatar: '/images/avatar-6.jpg',
    quote:
      'The placement test website is brilliantly designed. Clean interface, clear instructions, and immediate results. Highly professional work.',
    name: 'Karim A.',
  },
]

const socialLinks = [
  { icon: Youtube, href: 'https://youtube.com/@englishhub-f1z', label: 'YouTube' },
  {
    icon: Twitter,
    href: 'https://www.tiktok.com/@mr.rabie50',
    label: 'TikTok',
  },
  {
    icon: Linkedin,
    href: 'https://www.linkedin.com/in/tamerrabie62',
    label: 'LinkedIn',
  },
  {
    icon: Facebook,
    href: 'https://www.facebook.com/share/196NNPq4QS',
    label: 'Facebook',
  },
  {
    icon: Instagram,
    href: 'https://www.instagram.com/tamer50523',
    label: 'Instagram',
  },
  {
    icon: Twitter,
    href: 'https://x.com/TamerRabie62',
    label: 'X',
  },
]

const experience = [
  {
    icon: GraduationCap,
    role: 'Educational Content Designer',
    company: 'English Learning Hub (Self-Founded)',
    period: '2023 – Present',
    description:
      'Creating comprehensive English learning content across YouTube, TikTok, and Instagram. Developing online placement tests and interactive educational tools for Arabic-speaking learners.',
  },
  {
    icon: Heart,
    role: 'Dental Technician',
    company: 'Dental Laboratories, Cairo',
    period: '2009 – 2024',
    description:
      '15 years of specialized experience in dental prosthetics and crown fabrication. Developed meticulous attention to detail and precision craftsmanship that now informs my design work.',
  },
]

/* ─────────────── components ─────────────── */

function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false)
  const navItems = ['Home', 'About', 'Portfolio', 'Testimonials', 'Resume', 'Contact']

  const handleNavClick = (item: string) => {
    setMenuOpen(false)
    const target = item === 'Home' ? '#hero' : `#${item.toLowerCase()}`
    const el = document.querySelector(target)
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 h-14 bg-dark/90 backdrop-blur-md border-b border-dark-border">
        <div className="max-w-[1200px] mx-auto h-full flex items-center justify-between px-6 md:px-12">
          <a href="#hero" className="font-display text-2xl font-semibold text-white hover:text-orange transition-colors duration-300">
            Tamer
          </a>
          <button
            onClick={() => setMenuOpen(true)}
            className="text-white hover:text-orange transition-colors duration-300"
            aria-label="Open menu"
          >
            <Menu size={24} />
          </button>
        </div>
      </nav>

      {/* Full-screen menu overlay */}
      <div
        className={`fixed inset-0 z-[100] bg-dark/95 backdrop-blur-lg transition-all duration-500 ${
          menuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        <button
          onClick={() => setMenuOpen(false)}
          className="absolute top-4 right-6 md:right-12 text-white hover:text-orange transition-colors duration-300"
          aria-label="Close menu"
        >
          <X size={28} />
        </button>
        <div className="flex flex-col items-center justify-center h-full gap-8">
          {navItems.map((item, i) => (
            <button
              key={item}
              onClick={() => handleNavClick(item)}
              className="font-display text-4xl md:text-5xl text-white hover:text-orange transition-colors duration-300"
              style={{
                transitionDelay: menuOpen ? `${i * 0.1}s` : '0s',
                opacity: menuOpen ? 1 : 0,
                transform: menuOpen ? 'translateY(0)' : 'translateY(20px)',
                transition: 'all 0.5s cubic-bezier(0.0, 0, 0.2, 1)',
              }}
            >
              {item}
            </button>
          ))}
        </div>
      </div>
    </>
  )
}

function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const cardsRef = useRef<HTMLDivElement>(null)
  const profileRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.contact-card', {
        y: 30,
        opacity: 0,
        duration: 0.6,
        stagger: 0.15,
        ease: 'power2.out',
        delay: 0.3,
      })
      gsap.from(profileRef.current, {
        y: 40,
        opacity: 0,
        duration: 0.8,
        ease: 'power2.out',
        delay: 0.8,
      })
    }, sectionRef)
    return () => ctx.revert()
  }, [])

  return (
    <section
      id="hero"
      ref={sectionRef}
      className="relative w-full h-[500px] md:h-[600px] flex items-start justify-center overflow-visible"
    >
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: 'url(/images/hero-bg.jpg)' }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-dark/30 via-dark/50 to-dark" />
      </div>

      {/* Contact cards */}
      <div
        ref={cardsRef}
        className="relative z-10 w-full max-w-[1200px] px-6 md:px-12 pt-24 md:pt-28"
      >
        <div className="flex flex-col md:flex-row gap-4">
          {[
            { icon: MapPin, text: 'Maadi, Cairo, Egypt' },
            { icon: Phone, text: '+20 113 141 3200' },
            { icon: Mail, text: 'Mr.tamer2026@outlook.com' },
          ].map(({ icon: Icon, text }, i) => (
            <div
              key={i}
              className="contact-card flex-1 flex items-center gap-3 bg-orange rounded-xl px-5 py-4 shadow-[0_4px_16px_rgba(232,102,58,0.3)] hover:translate-y-[-4px] hover:shadow-[0_8px_24px_rgba(232,102,58,0.4)] transition-all duration-300 cursor-default"
            >
              <Icon size={16} className="text-white flex-shrink-0" />
              <span className="text-white text-xs font-medium tracking-wide">{text}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Profile area */}
      <div
        ref={profileRef}
        className="absolute bottom-[-60px] left-0 right-0 z-20 text-center"
      >
        <div className="inline-block">
          <img
            src="/images/profile.jpg"
            alt="Tamer Rabie"
            className="w-[120px] h-[120px] rounded-full object-cover border-4 border-dark mx-auto hover:scale-105 transition-transform duration-300"
          />
        </div>
        <h1 className="font-display text-4xl md:text-5xl font-bold text-white mt-4">
          Tamer Rabie
        </h1>
        <p className="text-text-secondary text-base mt-1">Educational Content Designer</p>
      </div>
    </section>
  )
}

function HelloCardSection() {
  const cardRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(cardRef.current, {
        scale: 0.95,
        opacity: 0,
        duration: 0.6,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: cardRef.current,
          start: 'top 80%',
          once: true,
        },
      })
    })
    return () => ctx.revert()
  }, [])

  return (
    <section className="pt-[100px] pb-10 px-6 md:px-12">
      <div
        ref={cardRef}
        className="max-w-[560px] mx-auto bg-white-card rounded-2xl p-10 md:p-12 text-center shadow-[0_8px_32px_rgba(0,0,0,0.2)]"
      >
        <h2 className="font-display text-4xl font-bold text-dark">Hello!</h2>
        <h3 className="font-display text-xl font-semibold text-orange mt-2">A Bit About Me</h3>
        <p className="text-[#555555] text-[15px] leading-relaxed mt-5 max-w-[440px] mx-auto">
          I'm an educational content designer based in Cairo, with 15 years of experience in dental
          technology. I love creating clear, simple, and unique learning experiences. I also enjoy
          crafting visual content that makes education accessible to everyone.
        </p>
        <a
          href="#about"
          className="inline-block mt-6 text-orange font-semibold text-sm tracking-wide hover:underline hover:text-orange-hover transition-colors duration-300"
        >
          Read My Story &darr;
        </a>
      </div>
    </section>
  )
}

function AboutSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const pills = [
    { label: 'RESUME', target: '#resume' },
    { label: 'MY SKILLS', target: '#skills' },
    { label: 'PROJECTS', target: '#portfolio' },
    { label: 'CONTACT', target: '#contact' },
  ]

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.about-name', {
        y: 40,
        opacity: 0,
        duration: 0.8,
        ease: 'power2.out',
        scrollTrigger: { trigger: sectionRef.current, start: 'top 70%', once: true },
      })
      gsap.from('.about-bio', {
        opacity: 0,
        duration: 0.6,
        delay: 0.2,
        ease: 'power2.out',
        scrollTrigger: { trigger: sectionRef.current, start: 'top 70%', once: true },
      })
      gsap.from('.nav-pill', {
        scale: 0.9,
        opacity: 0,
        duration: 0.5,
        stagger: 0.12,
        ease: 'power2.out',
        scrollTrigger: { trigger: '.pills-container', start: 'top 80%', once: true },
      })
    }, sectionRef)
    return () => ctx.revert()
  }, [])

  const handlePillClick = (target: string) => {
    const el = document.querySelector(target)
    if (el) el.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <section id="about" ref={sectionRef} className="py-20 px-6 md:px-12">
      <div className="max-w-[1200px] mx-auto text-center">
        <h2 className="about-name font-display text-[52px] font-bold text-orange tracking-tight">
          Tamer Rabie
        </h2>
        <p className="about-bio text-text-secondary text-base max-w-[680px] mx-auto leading-relaxed mt-6">
          I'm a content creator passionate about education, language learning, and helping others
          discover new worlds through knowledge. With a background in dental technology spanning 15
          years, I've honed a meticulous eye for detail and precision. Today, I channel that
          craftsmanship into designing educational experiences — from building placement tests to
          creating English learning content that empowers learners across Egypt and beyond.
        </p>

        <div className="pills-container flex flex-wrap justify-center gap-6 mt-12">
          {pills.map((pill) => (
            <button
              key={pill.label}
              onClick={() => handlePillClick(pill.target)}
              className="nav-pill w-[100px] h-[100px] rounded-full border-2 border-dark-border bg-transparent flex items-center justify-center text-text-secondary text-[11px] font-medium tracking-[0.08em] uppercase hover:border-orange hover:text-orange hover:bg-orange/[0.05] transition-all duration-300"
            >
              {pill.label}
            </button>
          ))}
        </div>
      </div>
    </section>
  )
}

function SkillsSection() {
  const sectionRef = useRef<HTMLElement>(null)

  const skills = [
    'Content Design',
    'English Teaching',
    'HTML/CSS/JS',
    'Video Editing',
    'Social Media',
    'Brand Identity',
    'UI/UX Design',
    'Public Speaking',
  ]

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.skill-tag', {
        y: 20,
        opacity: 0,
        duration: 0.5,
        stagger: 0.08,
        ease: 'power2.out',
        scrollTrigger: { trigger: sectionRef.current, start: 'top 75%', once: true },
      })
    }, sectionRef)
    return () => ctx.revert()
  }, [])

  return (
    <section id="skills" ref={sectionRef} className="py-16 px-6 md:px-12 border-t border-dark-border">
      <div className="max-w-[800px] mx-auto text-center">
        <h2 className="font-display text-3xl md:text-4xl font-bold text-white">My Skills</h2>
        <p className="text-text-muted text-sm mt-3">Technologies and expertise I've developed over the years.</p>
        <div className="flex flex-wrap justify-center gap-3 mt-10">
          {skills.map((skill) => (
            <span
              key={skill}
              className="skill-tag px-6 py-3 bg-dark-card border border-dark-border rounded-full text-text-secondary text-sm font-medium hover:border-orange hover:text-orange transition-all duration-300"
            >
              {skill}
            </span>
          ))}
        </div>
      </div>
    </section>
  )
}

function PortfolioSection() {
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.portfolio-heading', {
        y: 30,
        opacity: 0,
        duration: 0.6,
        ease: 'power2.out',
        scrollTrigger: { trigger: sectionRef.current, start: 'top 75%', once: true },
      })
      gsap.from('.portfolio-card', {
        y: 40,
        opacity: 0,
        duration: 0.6,
        stagger: 0.15,
        ease: 'power2.out',
        scrollTrigger: { trigger: '.portfolio-grid', start: 'top 80%', once: true },
      })
    }, sectionRef)
    return () => ctx.revert()
  }, [])

  return (
    <section id="portfolio" ref={sectionRef} className="py-20 px-6 md:px-12">
      <div className="max-w-[1200px] mx-auto">
        <div className="portfolio-heading text-center">
          <h2 className="font-display text-4xl font-bold text-white">My Portfolio</h2>
          <p className="text-text-muted text-sm max-w-[560px] mx-auto mt-3 leading-relaxed">
            A selection of projects showcasing my work in educational content design, web
            development, and visual branding.
          </p>
        </div>

        <div className="portfolio-grid grid grid-cols-1 md:grid-cols-2 gap-6 mt-12">
          {portfolioItems.map((item, i) => (
            <div
              key={i}
              className="portfolio-card group bg-dark-card rounded-xl overflow-hidden border border-transparent hover:border-dark-border hover:shadow-[0_8px_24px_rgba(0,0,0,0.4)] transition-all duration-300"
            >
              <div className="overflow-hidden">
                <img
                  src={item.img}
                  alt={item.title}
                  className="w-full aspect-video object-cover group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                />
              </div>
              <div className="p-5 pb-6">
                <h3 className="font-display text-lg font-semibold text-white">{item.title}</h3>
                <p className="text-text-muted text-xs font-medium uppercase tracking-wider mt-1">
                  {item.category}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function TestimonialsSection() {
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.testimonials-heading', {
        y: 30,
        opacity: 0,
        duration: 0.6,
        ease: 'power2.out',
        scrollTrigger: { trigger: sectionRef.current, start: 'top 75%', once: true },
      })
      gsap.from('.testimonial-card', {
        y: 30,
        opacity: 0,
        duration: 0.5,
        stagger: 0.1,
        ease: 'power2.out',
        scrollTrigger: { trigger: '.testimonials-grid', start: 'top 80%', once: true },
      })
    }, sectionRef)
    return () => ctx.revert()
  }, [])

  return (
    <section id="testimonials" ref={sectionRef} className="py-20 px-6 md:px-12">
      <div className="max-w-[1200px] mx-auto">
        <div className="testimonials-heading text-center">
          <h2 className="font-display text-4xl font-bold text-white">Testimonials</h2>
          <p className="text-text-muted text-sm mt-3">
            What students and colleagues say about working with me.
          </p>
        </div>

        <div className="testimonials-grid grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-12">
          {testimonials.map((t, i) => (
            <div key={i} className="testimonial-card flex gap-4 p-5">
              <img
                src={t.avatar}
                alt={t.name}
                className="w-14 h-14 rounded-full object-cover border-2 border-orange flex-shrink-0 hover:shadow-[0_0_12px_rgba(232,102,58,0.3)] transition-shadow duration-300"
                loading="lazy"
              />
              <div>
                <p className="text-text-secondary text-sm italic leading-relaxed">"{t.quote}"</p>
                <p className="text-orange text-xs font-semibold uppercase tracking-wider mt-3">
                  {t.name}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function ResumeSection() {
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.resume-heading', {
        y: 30,
        opacity: 0,
        duration: 0.6,
        ease: 'power2.out',
        scrollTrigger: { trigger: sectionRef.current, start: 'top 75%', once: true },
      })
      gsap.from('.experience-entry', {
        y: 40,
        opacity: 0,
        duration: 0.6,
        stagger: 0.2,
        ease: 'power2.out',
        scrollTrigger: { trigger: '.experience-list', start: 'top 80%', once: true },
      })
    }, sectionRef)
    return () => ctx.revert()
  }, [])

  return (
    <section id="resume" ref={sectionRef} className="py-20 px-6 md:px-12">
      <div className="max-w-[1200px] mx-auto">
        <div className="resume-heading text-center">
          <h2 className="font-display text-4xl font-bold text-white">Experience</h2>
          <p className="text-text-muted text-sm mt-3">
            A journey from healthcare craftsmanship to creative education.
          </p>
        </div>

        <div className="experience-list max-w-[800px] mx-auto mt-12 space-y-4">
          {experience.map((exp, i) => (
            <div
              key={i}
              className="experience-entry flex gap-6 p-8 bg-dark-card rounded-xl hover:bg-[#333333] hover:border-l-[3px] hover:border-l-orange transition-all duration-300"
            >
              <div className="w-12 h-12 rounded-full bg-orange/10 flex items-center justify-center flex-shrink-0">
                <exp.icon size={22} className="text-orange" />
              </div>
              <div>
                <h3 className="font-display text-xl font-semibold text-white">{exp.role}</h3>
                <p className="text-orange text-sm font-medium mt-1">{exp.company}</p>
                <p className="text-text-muted text-xs font-medium tracking-wider mt-1">
                  {exp.period}
                </p>
                <p className="text-text-secondary text-sm leading-relaxed mt-3">
                  {exp.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function ContactSection() {
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.contact-heading', {
        y: 30,
        opacity: 0,
        duration: 0.6,
        ease: 'power2.out',
        scrollTrigger: { trigger: sectionRef.current, start: 'top 75%', once: true },
      })
      gsap.from('.social-icon', {
        scale: 0.8,
        opacity: 0,
        duration: 0.4,
        stagger: 0.08,
        ease: 'power2.out',
        scrollTrigger: { trigger: '.social-links', start: 'top 85%', once: true },
      })
    }, sectionRef)
    return () => ctx.revert()
  }, [])

  return (
    <section id="contact" ref={sectionRef} className="py-20 px-6 md:px-12 border-t border-dark-border">
      <div className="max-w-[800px] mx-auto text-center">
        <div className="contact-heading">
          <h2 className="font-display text-4xl font-bold text-white">Get In Touch</h2>
          <p className="text-text-secondary text-base mt-3">
            Let's collaborate on your next educational project.
          </p>
        </div>

        <div className="social-links flex flex-wrap justify-center gap-5 mt-10">
          {socialLinks.map(({ icon: Icon, href, label }) => (
            <a
              key={label}
              href={href}
              target="_blank"
              rel="noopener noreferrer"
              className="social-icon w-12 h-12 rounded-full border border-dark-border flex items-center justify-center text-text-muted hover:text-orange hover:border-orange hover:bg-orange/[0.05] transition-all duration-300"
              aria-label={label}
            >
              <Icon size={22} />
            </a>
          ))}
        </div>

        <div className="mt-10 space-y-2">
          <a
            href="mailto:Mr.tamer2026@outlook.com"
            className="block text-orange text-base font-medium hover:underline"
          >
            Mr.tamer2026@outlook.com
          </a>
          <p className="text-text-secondary text-sm">+20 113 141 3200</p>
          <p className="text-text-muted text-sm">Maadi, Cairo, Egypt</p>
        </div>

        <div className="mt-16 pt-6 border-t border-dark-border">
          <p className="text-text-muted text-xs">
            &copy; 2025 Tamer Rabie. All rights reserved.
          </p>
        </div>
      </div>
    </section>
  )
}

function FloatingMoreButton() {
  const handleClick = () => {
    const el = document.querySelector('#contact')
    if (el) el.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <button
      onClick={handleClick}
      className="fixed bottom-6 right-6 z-40 bg-white text-dark px-5 py-3 rounded-lg font-semibold text-sm shadow-[0_4px_16px_rgba(0,0,0,0.3)] hover:bg-[#F0F0F0] hover:translate-y-[-2px] hover:shadow-[0_6px_20px_rgba(0,0,0,0.4)] transition-all duration-300 flex items-center gap-2"
    >
      More <ArrowDown size={16} />
    </button>
  )
}

/* ─────────────── main app ─────────────── */

export default function App() {
  return (
    <div className="min-h-screen bg-dark text-white">
      <Navbar />
      <HeroSection />
      <HelloCardSection />
      <AboutSection />
      <SkillsSection />
      <PortfolioSection />
      <TestimonialsSection />
      <ResumeSection />
      <ContactSection />
      <FloatingMoreButton />
    </div>
  )
}
